browser.webRequest.onBeforeRequest.addListener(
  (requestDetails) => {
    if (/^https?:\/\/(www\.)?(youtube\.com|youtu\.be)/.test(requestDetails.url)) {
      const redirectUrl = `freetube://${requestDetails.url}`;

      browser.storage.local.set({ tabIdToClose: requestDetails.tabId });

      return { redirectUrl };
    }
  },
  { urls: ["*://*.youtube.com/*", "*://*.youtu.be/*"] },
  ["blocking"]
);

browser.webRequest.onCompleted.addListener(
  async (details) => {
    const { tabIdToClose } = await browser.storage.local.get('tabIdToClose');

    if (tabIdToClose === details.tabId) {
      // Close the tab after a short delay (e.g., 1 second) to ensure the redirect has gone through
      setTimeout(() => {
        browser.tabs.remove(tabIdToClose).catch((error) => {
          console.error('Failed to remove tab:', error);
        });
      }, 1000);
    }
  },
  { urls: ["*://*.youtube.com/*", "*://*.youtu.be/*"] }
);

